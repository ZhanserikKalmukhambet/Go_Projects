create function inc2(num integer) returns integer
    language plpgsql
as
$$
declare
    inner_res integer;
begin
    inner_res := num + 1;
    return inner_res;
end
$$;

alter function inc2(integer) owner to postgres;

