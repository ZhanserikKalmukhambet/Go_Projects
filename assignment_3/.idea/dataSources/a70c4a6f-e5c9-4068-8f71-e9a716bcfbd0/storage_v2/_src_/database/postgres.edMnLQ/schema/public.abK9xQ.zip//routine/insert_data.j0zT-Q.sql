create procedure insert_data()
    language plpgsql
as
$$
    declare
        stud record;
    begin
        for stud in select name from students
        loop
            raise notice '%', stud.name;
            end loop;
    end
$$;

alter procedure insert_data() owner to postgres;

