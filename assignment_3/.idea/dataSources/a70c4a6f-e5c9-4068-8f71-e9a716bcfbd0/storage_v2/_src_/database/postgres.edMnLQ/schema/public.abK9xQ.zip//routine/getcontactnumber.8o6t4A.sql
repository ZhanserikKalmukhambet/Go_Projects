create function getcontactnumber()
    returns TABLE(contact character varying, tel_number character varying)
    language plpgsql
as
$$
begin
   return query
       select p.contact, p.tel_number from phonebook as p;
end
$$;

alter function getcontactnumber() owner to postgres;

