create procedure ins_or_upd(IN name character varying, IN surname character varying, IN email character varying, IN date_of_birth date, IN country_of_birth character varying)
    language plpgsql
as
$$
begin
    if exists(select * from person where name = $1 and surname = $2)
        then
        update person set email = $3
        where first_name = $1 and last_name = $2;
    else
        insert into person(first_name, last_name, email, date_of_birth, country_of_birth)
                values($1, $2, $3, $4, $5);
    end if;
end;
$$;

alter procedure ins_or_upd(varchar, varchar, varchar, date, varchar) owner to postgres;

