create function scorebetweentwo(num1 integer, num2 integer)
    returns TABLE(user_name character varying, user_score integer)
    language plpgsql
as
$$
begin
    return query
        select sg.user_name, sg.user_score from snake_game as sg
        where sg.user_score between num1 and num2;
end
$$;

alter function scorebetweentwo(integer, integer) owner to postgres;

