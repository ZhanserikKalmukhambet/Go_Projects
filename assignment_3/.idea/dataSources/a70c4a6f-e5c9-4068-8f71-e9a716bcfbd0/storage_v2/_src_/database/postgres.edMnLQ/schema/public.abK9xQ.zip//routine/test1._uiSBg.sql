create function test1() returns integer
    language plpgsql
as
$$
begin
    return 7;
end
$$;

alter function test1() owner to postgres;

