create procedure insert_list(IN name character varying, IN number character varying)
    language plpgsql
as
$$
    begin
        insert into phonebook(contact, tel_number) values ($1, $2);
    end;
$$;

alter procedure insert_list(varchar, varchar) owner to postgres;

