create function getuser(id integer) returns character varying
    language plpgsql
as
$$
declare
    user_s_name varchar;
begin
    select sg.user_name into user_s_name from snake_game as sg where sg.id = $1;
    return user_s_name;
end
$$;

alter function getuser(integer) owner to postgres;

