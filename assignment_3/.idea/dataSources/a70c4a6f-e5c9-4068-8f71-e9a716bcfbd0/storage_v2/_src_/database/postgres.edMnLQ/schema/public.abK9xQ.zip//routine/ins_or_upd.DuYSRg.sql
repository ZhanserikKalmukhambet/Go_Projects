create procedure ins_or_upd(IN _contact character varying, IN _tel character varying, IN _conn character varying, IN _email character varying, IN _relation character varying)
    language plpgsql
as
$$
begin
    if exists(select * from phonebook where tel_number = $2)
        then
        UPDATE phonebook
        SET contact = $1,
            tel_connection = $3,
            email = $4,
            relationship = $5
        WHERE tel_number = $2;
    else
        INSERT INTO phonebook(contact, tel_number, tel_connection, email, relationship)
               VALUES($1, $2, $3, $4, $5);
    end if;
end;
$$;

alter procedure ins_or_upd(varchar, varchar, varchar, varchar, varchar) owner to postgres;

