create procedure delete(IN type character varying)
    language plpgsql
as
$$
begin
    delete from phonebook where contact = $1 or tel_number = $1;
end
$$;

alter procedure delete(varchar) owner to postgres;

