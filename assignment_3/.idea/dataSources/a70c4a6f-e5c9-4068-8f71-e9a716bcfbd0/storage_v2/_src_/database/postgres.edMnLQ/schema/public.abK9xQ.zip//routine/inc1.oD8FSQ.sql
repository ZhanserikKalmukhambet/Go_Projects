create function inc1(num integer) returns integer
    language plpgsql
as
$$
begin
    return num + 1;
end
$$;

alter function inc1(integer) owner to postgres;

