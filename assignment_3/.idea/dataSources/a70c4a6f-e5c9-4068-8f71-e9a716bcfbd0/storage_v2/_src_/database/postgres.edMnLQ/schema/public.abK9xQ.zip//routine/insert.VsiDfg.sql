create procedure insert(IN name character varying, IN phone character varying)
    language plpgsql
as
$$
begin
    insert into phonebook(contact, tel_number) VALUES($1, $2);
end
$$;

alter procedure insert(varchar, varchar) owner to postgres;

