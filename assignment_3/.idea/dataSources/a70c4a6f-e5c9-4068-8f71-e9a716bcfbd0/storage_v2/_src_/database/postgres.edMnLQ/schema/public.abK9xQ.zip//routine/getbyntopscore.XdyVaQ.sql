create function getbyntopscore()
    returns TABLE(id integer, user_name character varying, user_score integer)
    language plpgsql
as
$$
begin
    return query
        select sg.id, sg.user_name, sg.user_score
        from snake_game as sg
        order by sg.user_score desc
        limit 4;
end
$$;

alter function getbyntopscore() owner to postgres;

