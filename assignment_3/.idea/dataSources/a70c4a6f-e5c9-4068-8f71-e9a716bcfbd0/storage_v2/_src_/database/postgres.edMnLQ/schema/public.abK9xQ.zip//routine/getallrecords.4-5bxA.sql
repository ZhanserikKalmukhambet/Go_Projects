create function getallrecords(simcard character varying) returns record
    language plpgsql
as
$$
declare
    contact record;
begin
    select pb.contact,pb.relationship into contact from phonebook as pb where simcard = $1;
    return contact;
end;
$$;

alter function getallrecords(varchar) owner to postgres;

