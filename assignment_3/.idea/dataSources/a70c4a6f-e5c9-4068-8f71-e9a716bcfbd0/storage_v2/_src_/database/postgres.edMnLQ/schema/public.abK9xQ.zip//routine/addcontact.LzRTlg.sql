create procedure addcontact(IN name character varying, IN tel character varying, IN card character varying, IN email character varying, IN rel character varying)
    language plpgsql
as
$$
begin
    insert into phonebook(contact,tel_number,tel_connection,email,relationship)
        VALUES (name,tel,card,email,rel);
end
$$;

alter procedure addcontact(varchar, varchar, varchar, varchar, varchar) owner to postgres;

