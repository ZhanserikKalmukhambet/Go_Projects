create function test() returns integer
    language plpgsql
as
$$ 
   begin
      return 7;
   end
   $$;

alter function test() owner to postgres;

