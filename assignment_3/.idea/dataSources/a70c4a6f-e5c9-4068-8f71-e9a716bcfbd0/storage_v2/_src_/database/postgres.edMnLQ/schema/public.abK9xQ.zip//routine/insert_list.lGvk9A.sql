create procedure insert_list(IN l record)
    language plpgsql
as
$$
    declare
        ll record;
    begin
        ll = $1;
        insert into phonebook(contact, tel_number) VALUES (ll[0], ll[1]);
    end;
$$;

alter procedure insert_list(record) owner to postgres;

