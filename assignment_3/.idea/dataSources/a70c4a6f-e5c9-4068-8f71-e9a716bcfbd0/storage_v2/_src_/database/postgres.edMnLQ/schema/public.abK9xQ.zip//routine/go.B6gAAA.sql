create procedure go()
    language plpgsql
as
$$
declare
    person record;
begin
    for person in select contact from phonebook
        loop
            raise notice '%', person.contact;
        end loop;
end;
$$;

alter procedure go() owner to postgres;

