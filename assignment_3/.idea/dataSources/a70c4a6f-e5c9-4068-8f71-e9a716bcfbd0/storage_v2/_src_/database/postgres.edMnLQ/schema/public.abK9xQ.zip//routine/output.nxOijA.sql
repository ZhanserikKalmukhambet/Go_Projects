create function output(lim integer, simcard character varying)
    returns TABLE(contact character varying, tel_number character varying, tel_connection character varying)
    language plpgsql
as
$$
begin
    return query
        select pb.contact, pb.tel_number, pb.tel_connection from phonebook as pb
        where pb.tel_connection = $2
        ORDER BY pb.contact
        limit $1+1
        offset 1;
end
$$;

alter function output(integer, varchar) owner to postgres;

