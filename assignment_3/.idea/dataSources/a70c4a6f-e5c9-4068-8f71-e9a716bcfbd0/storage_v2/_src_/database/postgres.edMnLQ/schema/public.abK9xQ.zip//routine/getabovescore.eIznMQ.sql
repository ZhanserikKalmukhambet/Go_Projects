create function getabovescore(num integer)
    returns TABLE(user_name character varying, user_score integer)
    language plpgsql
as
$$
begin
    return query
        select sg.user_name, sg.user_score from snake_game as sg
        where sg.user_score >= $1;
end
$$;

alter function getabovescore(integer) owner to postgres;

