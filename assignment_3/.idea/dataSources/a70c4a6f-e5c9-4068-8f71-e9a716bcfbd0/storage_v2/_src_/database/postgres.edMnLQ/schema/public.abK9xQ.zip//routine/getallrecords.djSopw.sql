create function getallrecords()
    returns TABLE(contact character varying, tel_number character varying, tel_connection character varying, email character varying, relationship character varying)
    language plpgsql
as
$$
begin
    return query
        select * from phonebook;
end;
$$;

alter function getallrecords() owner to postgres;

