create function getemail(n integer) returns character varying
    language plpgsql
as
$$
    declare
        student record;
    begin
    for student in select email from students limit 3
        loop
            raise notice '%', student.email;
        end loop;
    end
$$;

alter function getemail(integer) owner to postgres;

