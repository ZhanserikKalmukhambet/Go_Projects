create procedure update(IN name character varying, IN phone character varying)
    language plpgsql
as
$$
begin
    UPDATE phonebook set tel_number = $2 where contact = $1;
end
$$;

alter procedure update(varchar, varchar) owner to postgres;

