create function getbyntopscore(lim integer)
    returns TABLE(id integer, user_name character varying, user_score integer)
    language plpgsql
as
$$
begin
    return query
        select sg.id, sg.user_name, sg.user_score
        from snake_game as sg
        order by user_score desc
        limit lim;
end
$$;

alter function getbyntopscore(integer) owner to postgres;

